From mathcomp Require Import all_ssreflect.
From det Require Import tree elpi t2l list.

Section Nur.
Open Scope L.

Variable u : Unif.

Fixpoint of_goals l :=
  match l with
    | [::]%SEQ => [::]%G
    | [:: hd & xs]%SEQ => [:: (hd.1, hd.2) & of_goals xs]%G
  end.

Fixpoint of_alt l :=
  match l with
  | [::]%SEQ => [::]%A
  | [:: x & xs]%SEQ => (empty, of_goals x) :: (of_alt xs)
  end.

Definition clean_ca_G f (g : Atom * alts) :=
  match g with
  | (call a, ca) => (call a, [::])
  | (cut, ca) => (cut, f ca)
  end.

Fixpoint clean_ca_goals gl :=
  match gl with
  | nilG => nilC 
  | consG hd tl => (clean_ca_G clean_ca hd) :: (clean_ca_goals tl)
  end
with clean_ca (ats: alts) : alts :=
  match ats with
  | nilA => nilC
  | consA (hd,xs) tl => (hd, clean_ca_goals xs) :: (clean_ca tl)
  end.

Definition tester l r :=
  clean_ca (tree_to_stack l empty nilC) = r.

Goal forall B B0,
let f x := (TA (call x)) in
let g x := ([:: (call x) ]%SEQ) in
  tester (And (Or (Some OK) empty (f B)) (g B0) KO) 
    ((empty, (call B,[::]) :: ((call B0,[::]) :: nilC)) :: nilC).
Proof.
  by move=> //.
Qed.

Definition callN A := (call A, nilA).

Goal forall A B D0 D,
  (* (((! \/ A) \/ B)) /\ (D) *)
  let f x := (TA (call x)) in
  let g x := ([::call x]%SEQ) in
  tester 
    (And (Or ((Some (Or (Some (TA cut)) empty (f A)))) empty (f B)) (g D0) (f D)) 
    (of_alt [:: 
      [:: (cut, of_alt [:: [:: (callN B); (callN D0)]%SEQ]); (callN D)];
      [:: (callN A); (callN D0)]; 
      [:: (callN B); (callN D0)]]%SEQ).
Proof.
  move=> A B D0 D p/=.
  move=>//=.
Qed.


Goal forall B C D E F,
  let f x := (TA (call x)) in
  let g x := ([::call x]%SEQ) in
  (* (A \/_{empty} B) /\_C ((! \/_{empty} D) /\_{E} F) *)
  tester 
    (And (Or (Some OK) empty (f B)) (g C) (And (Or (Some (TA cut)) empty (f D)) (g E) (f F)))
    (of_alt [:: 
      [:: (cut, (of_alt [:: [:: callN B; callN C]])); callN F];
      [:: callN D; callN E]; 
      [:: callN B; callN C]])%SEQ.
Proof.
  move=> B C D E F p/=.
  rewrite //.
Qed.

Definition g x := ([::call x]%SEQ).
(* THIS CAN NO MORE EXISTS: reset is never KO *)
(* Goal forall A B C,
  let f x := (TA (call x)) in
  (* (((! \/ A) \/ B)) /\ (! \/ C)*)
  tester 
    (And (Or ((Or (TA cut) empty (f A))) empty (f B)) KO (Or (TA cut) empty (f C))) 
    (of_alt [:: 
      [::cut nilC ; cut nilC ];
      [::cut nilC ; call p C]]%SEQ).
Proof.
  move=> A B C p/=.
  rewrite/tree_to_stack//.
Qed. *)

Goal forall A B C0 C,
  let f x := (TA (call x)) in
  let g x := ([::call x]%SEQ) in
  (* (((! \/ A) \/ B)) /\ (! \/ C)*)
  tester 
    (And (Or ((Some (Or (Some (TA cut)) empty (f A)))) empty (f B)) (g C0) (Or (Some (TA cut)) empty (f C)))
    (of_alt[:: 
      [::(cut, (of_alt [:: [:: callN B; callN C0]])); (cut, (of_alt [::[:: callN A; callN C0]; [:: callN B; callN C0]]))];
      [::(cut, (of_alt [:: [:: callN B; callN C0]])); callN C];
      [:: callN A; callN C0]; 
      [:: callN B; callN C0]]%SEQ).
Proof.
  move=> A B C0 C p//=.
Qed.



Goal forall A B0,
    (* (OK \/ A) /\_B0 OK *)
  let f x := (TA (call x)) in
  let g x := ([::call x]%SEQ) in
  tester (And (Or (Some OK) empty (f A)) (g B0) OK) (of_alt [::[::]; [::callN A; callN B0]]%SEQ).
Proof.
  move=> A B0 p.
  rewrite/tree_to_stack//=.
Qed.

Goal forall A B0,
  (* (KO \/ B) /\_b0 B0  *)
  let f x := (TA (call x)) in
  let g x := ([::call x]%SEQ) in
  tester (And (Or (Some KO) empty (f A)) (g B0) (f B0))
  (of_alt [::[::callN A; callN B0]]%SEQ).
Proof.
  move=> A B0 p.
  rewrite/tree_to_stack//=.
Qed.

Goal forall x y z w a, 
  let f x := (TA (call x)) in
  let g x := ([::call x]%SEQ) in
  tester (
    And 
      (Or (Some (f x)) empty (f y)) (g a) 
      (Or (Some (f z)) empty (f w))) 
    (of_alt [:: [:: callN x; callN z];
    [:: callN x; callN w];
    [:: callN y; callN a]]%SEQ).
Proof.
  move=>/=.
  by [].
Qed.

Goal forall z w a, 
  let f x := (TA (call x)) in
  tester (
    And 
      (Or (Some OK) empty KO) (g a) 
      (Or (Some (f z)) empty (f w))) 
    (of_alt [:: [:: callN z]; [:: callN w]]%SEQ).
Proof.
  move=>p z w a.
  rewrite/tree_to_stack/=.
  by [].
Qed.

(* THIS IS IMPORTANT *)
Goal forall a b c d, 
  let f x := (TA (call x)) in
  tester (
    And 
      (Or (Some KO) empty (f a)) (g b) 
      (Or (Some (f c)) empty (f d))) 
    (* [:: [:: callN a; call b] ]. *)
    (of_alt [:: [:: callN a; callN c]; [::callN a; callN d] ]%SEQ).
Proof.
  move=> a b c d /=.
  by [].
Qed.

Goal forall a b, 
(* (! \/ a) \/ b *)
  tester (
    Or 
      (Some (Or (Some (TA cut)) empty (TA (call a)))) empty
      (TA (call b)))
  (of_alt [:: [:: (cut, (of_alt[:: [:: callN b]]))]; [:: callN a]; [:: callN b]]%SEQ).
Proof.
  move=> a b; rewrite/tree_to_stack/=.
  by []. Qed.

(* Goal forall A1 A2 s  C0 B,
  let f x := (TA (call x)) in
  tester (And (Or (f A1) s (f A2)) (KO) (And KO (f C0) (f B))) nilC
  .
Proof.
  move=> A1 A2 s  C0 B p.
  rewrite/tree_to_stack.
  by [].
Qed. *)

(* Goal forall A B C,
  let f x := (TA (call x)) in
  tester (And (Or (f A) empty (f B)) (KO) (f C))
  (of_alt[:: [:: callN A; call p C]]%SEQ).
Proof.
  move=> s A B C p.
  rewrite/tree_to_stack/=.
  by [].
Qed. *)

Goal forall A1 A2 B0 C0 B,
  let f x := (TA (call x)) in
  tester (And (Or (Some (f A1)) empty (f A2)) (g B0) (And KO (g C0) (f B)))
  (of_alt [:: [:: callN A2 ; callN B0 ]]%SEQ).
Proof.
  move=> * /=.
  by [].
Qed.

Goal forall b0 a b c, 
  tester (
    Or 
      (Some (Or (Some (And (TA (call c)) (g b0) (TA cut))) empty (TA (call a)))) empty
      (TA (call b)))
  (of_alt[:: [:: callN c; (cut, (of_alt[:: [:: callN b]]))]; [:: callN a]; [:: callN b]]%SEQ).
Proof.
  move=> b0 p a b .
  rewrite/tree_to_stack/=.
  rewrite//=.
Qed.

Goal forall B C Res,
  let f x := (TA (call x)) in
  (* (OK \/ B) /\ (! \/ C) -> [cut_[B,Reset]; C; (B, Reset)] *)
  tester (And (Or (Some OK) empty (f B)) (g Res) (Or (Some (TA cut)) empty (f C))) 
    (of_alt[::[::(cut, (of_alt[::[:: callN B; callN Res]]))]; [::callN C]; [:: callN B; callN Res]]%SEQ).
Proof.
  move=> B C Res p.
  rewrite /tree_to_stack/=.
  move=>//.
Qed.

Goal forall B C Res Reempty,
  let f x := (TA (call x)) in
  (* (OK \/ B) /\ (! /\ C) -> [cut_[]; C; (B, Reset)] *)
  tester (And (Or (Some OK) empty (f B)) (g Res) (And (TA cut) (g Reempty) (f C))) 
    (of_alt[::[::(cut, nilC); callN C]; [:: callN B; callN Res]]%SEQ).
Proof.
  move=> B C Res Reempty p/=.
  rewrite/tree_to_stack/=.
  f_equal => //.
Qed.

Goal forall A B C C0,
  let f x := (TA (call x)) in
  (* (A /\ ((! \/ B) \/ C) *)
  tester (And (f A) (g C0) (Or (Some (Or (Some (TA cut)) empty (f B))) empty (f C))) 
  (of_alt [:: 
    [:: callN A; (cut, (of_alt[:: [:: callN C]]))]; 
    [:: callN A; callN B]; 
    [:: callN A; callN C]]%SEQ).
Proof.
  move=> A B C C0 p.
  rewrite /tree_to_stack/=.
  repeat f_equal => //.
Qed.

Goal forall A B C D E,
  let f x := (TA (call x)) in
  (* (A \/_{empty} B) /\_C ((! \/_{empty} D) \/_{empty} E) *)
  tester 
    (And (Or (Some (f A)) empty (f B)) (g C) (Or (Some (Or (Some (TA cut)) empty (f D))) empty (f E))) 
    (of_alt[:: 
    [:: callN A; (cut, (of_alt [:: [:: callN E]; [:: callN B; callN C]]))];
    [:: callN A; callN D]; [:: callN A; callN E];
    [:: callN B; callN C]]%SEQ)
  .
Proof.
  by [].
Qed.

(* IMPORTANTE!
  The right and side of the first and becomes:
    (!,!); (D, E)
  The two cuts points to different cat_to alternatives:
  The first rejects (D,E) as choice points
  The second rejects (B,C) which is an alternatives at higher level
*)
Goal forall B C D E,
  let f x := (TA (call x)) in
  (* (OK \/_{empty} B) /\_C ((! \/_{empty} D) /\_{E} !) *)
  tester 
    (And (Or (Some OK) empty (f B)) (g C) (And (Or (Some (TA cut)) empty (f D)) (g E) (TA cut))) 
    (of_alt [:: 
      [:: (cut, (of_alt[:: [:: callN B; callN C]])); (cut, nilC) ];
      [:: callN D; callN E]; 
      [:: callN B; callN C]]%SEQ).
Proof.
  move=> B C D E p/=.
  rewrite/tree_to_stack/=.
  move=>//.
Qed.

Goal forall A B C,
  let f x := (TA (call x)) in
  (* ((! \/ ! \/ A) \/ B) \/ C *)
  tester
    (Or (Some (Or (Some (Or (Some (TA cut)) empty ((Or (Some (TA cut)) empty (f A))))) empty (f B))) empty (f C))
    (of_alt[:: 
      [::(cut, (of_alt[:: [:: callN B]; [::callN C]]))];
      [::(cut, (of_alt[:: [:: callN B]; [::callN C]]))];
      [:: callN A]; 
      [:: callN B];
      [:: callN C] ]%SEQ).
Proof.
  move=> A B C p/=.
  rewrite/tree_to_stack/=.
  move=>//=.
Qed.

Goal forall A B C,
  let f x := (TA (call x)) in
  (* ((! \/ ! \/ A) \/ B) \/ C *)
  tester 
    (Or (Some (Or (Some (Or (Some (And (TA cut) ([::]) OK)) empty ((Or (Some (TA cut)) empty (f A))))) empty (f B))) empty (f C)) 
    (of_alt[:: 
      [::(cut, (of_alt[:: [:: callN B]; [::callN C]]))];
      [::(cut, (of_alt[:: [:: callN B]; [::callN C]]))];
      [:: callN A]; 
      [:: callN B];
      [:: callN C] ]%SEQ).
Proof.
  move=> A B C p/=.
  rewrite/tree_to_stack/=.
  move=>//=.
Qed.


Goal forall A B C D0 D,
  let f x := (TA (call x)) in
  (* (((! \/ ! \/ A) \/ B) \/ C) /\ D*)
  tester
    (And (Or (Some (Or (Some (Or (Some (TA cut)) empty ((Or (Some (TA cut)) empty (f A))))) empty (f B))) empty (f C)) (g D0) (f D))
    (of_alt[:: 
      [::(cut, (of_alt [:: [:: callN B; callN D0]; [::callN C; callN D0]])); callN D];
      [::(cut, (of_alt [:: [:: callN B; callN D0]; [::callN C; callN D0]])); callN D0];
      [:: callN A; callN D0]; 
      [:: callN B; callN D0];
      [:: callN C; callN D0] ]%SEQ).
Proof.
  move=> A B C D0 D p/=.
  rewrite/tree_to_stack/=.
  f_equal => //.
Qed.

Goal forall X A B C D0 D,
  let f x := (TA (call x)) in
  (* ((X \/ ((! \/ ! \/ A) \/ B) \/ C)) /\ D*)
  tester 
    (And (Or (Some (f X)) empty (Or (Some (Or (Some (Or (Some (TA cut)) empty ((Or (Some (TA cut)) empty (f A))))) empty (f B))) empty (f C))) (g D0) (f D))
    (of_alt[:: 
      [:: callN X; callN D];
      [::(cut, (of_alt[:: [:: callN B; callN D0]; [::callN C; callN D0]])); callN D0];
      [::(cut, (of_alt[:: [:: callN B; callN D0]; [::callN C; callN D0]])); callN D0];
      [:: callN A; callN D0]; 
      [:: callN B; callN D0];
      [:: callN C; callN D0] ]%SEQ).
Proof.
  move=> X A B C D0 D p/=.
  rewrite/tree_to_stack/=.
  f_equal => //.
Qed.

Goal forall B0 A B C D,
  let f x := (TA (call x)) in
  (* (((A /\ (! \/ B)) \/ C \/ D)) *)
  tester 
    (Or (Some (Or (Some (f C)) empty (And (f A) (g B0) (Or (Some (TA cut)) empty (f B))))) empty (f D))
    (of_alt[:: 
      [:: callN C]; 
      [:: callN A; (cut, (of_alt[:: [:: callN D]]))]; 
      [:: callN A; callN B]; [:: callN D]]%SEQ).
Proof.
  move=> B0 A B C D p/=.
  rewrite/tree_to_stack/=.
  rewrite//.
Qed.

Goal forall A B C,
  let f x := (TA (call x)) in
  (* (((! \/ A) \/ !) \/ B) \/ C *)
  tester 
    (Or (Some (Or (Some (Or (Some (Or (Some (TA cut)) empty (f A))) empty (TA cut))) empty (f B))) empty (f C))
    (of_alt[:: 
      [::(cut, (of_alt[::[::(cut, (of_alt[::[::callN B]; [::callN C]]))]; [::callN B]; [::callN C]]))];
      [::callN A];
      [::(cut, (of_alt[::[::callN B]; [::callN C]]))];
      [::callN B];
      [::callN C]
    ]%SEQ).
Proof.
  move=> p A B C/=.
  rewrite/tree_to_stack/=.
  rewrite//.
Qed.
Goal forall p l,
  let s := ((Or (Some (Or None empty (TA cut))) empty OK)) in
  let bt := of_alt([::]%SEQ :: l) in
  tree_to_stack s empty (of_alt l) = of_alt[:: [:: (cut, bt)]; [::]]%SEQ /\ 
    tree_to_stack (odflt KO (prune true (step u p fset0 empty s).2)) empty (of_alt l) ++ (of_alt l) = bt.
Proof.
  move=>//= _ l.
  rewrite cat_cons cat0s//.
Qed.

End Nur.